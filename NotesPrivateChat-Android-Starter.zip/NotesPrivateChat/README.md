# Notes Private Chat — Android starter project

This is a **UI prototype**, not a finished secure messenger.

## What works
- Dark-themed Android screen named “Notes”
- Demo PIN screen (`2026`)
- Local-only demo chat UI

## What does NOT work yet
- Messages do not reach another phone
- No end-to-end encryption
- No disappearing-message timer
- No camera/photo/video sharing
- No secure private media storage
- No notification controls beyond this prototype not creating notifications

Do not use this prototype for confidential or intimate content. The PIN is hard-coded for demonstration and is not secure.

## Build
Open this folder in Android Studio and build the APK. A real two-device messenger requires a backend plus an established end-to-end encryption protocol and security review. Do not simply add custom encryption.
