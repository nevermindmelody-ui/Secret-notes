package com.example.notesprivatechat

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.text.InputType
import android.widget.*

class MainActivity : Activity() {
    private val bg = Color.rgb(12, 12, 16)
    private val panel = Color.rgb(25, 25, 33)
    private val purple = Color.rgb(174, 132, 255)
    private val white = Color.rgb(245, 245, 250)
    private var chatLayout: LinearLayout? = null
    private var messageInput: EditText? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showPinScreen()
    }

    private fun baseLayout(): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(24, 28, 24, 28)
            setBackgroundColor(bg)
            layoutParams = ViewGroup.LayoutParams(-1, -1)
        }
    }

    private fun title(text: String, size: Float = 28f): TextView =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(white)
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 16)
        }

    private fun button(text: String, action: () -> Unit): Button =
        Button(this).apply {
            this.text = text
            setTextColor(Color.BLACK)
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(purple))
            setOnClickListener { action() }
        }

    private fun showPinScreen() {
        val root = baseLayout()
        root.addView(title("Notes", 34f))
        root.addView(title("Your private space", 15f))
        val pin = EditText(this).apply {
            hint = "Enter 4-digit PIN"
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
            setTextColor(white)
            setHintTextColor(Color.GRAY)
            gravity = Gravity.CENTER
            textSize = 20f
            setSingleLine(true)
            setPadding(18, 14, 18, 14)
            backgroundTintList = android.content.res.ColorStateList.valueOf(purple)
        }
        root.addView(pin, LinearLayout.LayoutParams(-1, 60).apply {
            topMargin = 16; bottomMargin = 12
        })
        val error = title("", 14f)
        root.addView(error)
        root.addView(button("Unlock", {
            if (pin.text.toString() == "2026") {
                showDemoChat()
            } else {
                error.text = "Incorrect PIN"
            }
        }), LinearLayout.LayoutParams(-1, 54))
        root.addView(title("Prototype only — do not use for sensitive messages.", 12f))
        setContentView(root)
    }

    private fun showDemoChat() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 18, 16, 12)
            setBackgroundColor(bg)
        }
        root.addView(title("Notes", 26f))
        root.addView(title("Private chat prototype • this phone only", 12f))
        val warning = TextView(this).apply {
            text = "Demo mode: messages are not sent to another phone and are not end-to-end encrypted."
            setTextColor(Color.rgb(255, 190, 120))
            textSize = 13f
            setPadding(12, 12, 12, 12)
            setBackgroundColor(panel)
        }
        root.addView(warning)
        val scroll = ScrollView(this)
        val messages = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(4, 10, 4, 10)
        }
        chatLayout = messages
        scroll.addView(messages)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        messageInput = EditText(this).apply {
            hint = "Type a demo message"
            setTextColor(white)
            setHintTextColor(Color.GRAY)
            setBackgroundColor(panel)
            setPadding(12, 8, 12, 8)
        }
        row.addView(messageInput, LinearLayout.LayoutParams(0, 54, 1f))
        row.addView(button("Send", {
            val text = messageInput?.text?.toString()?.trim().orEmpty()
            if (text.isNotEmpty()) {
                addDemoMessage(text)
                messageInput?.setText("")
                val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                imm.hideSoftInputFromWindow(messageInput?.windowToken, 0)
            }
        }))
        root.addView(row)
        root.addView(button("Lock app", { showPinScreen() }))
        setContentView(root)
        addDemoMessage("Welcome. This is a local-only prototype.")
    }

    private fun addDemoMessage(text: String) {
        val item = TextView(this).apply {
            this.text = text
            textSize = 16f
            setTextColor(white)
            setPadding(14, 10, 14, 10)
            setBackgroundColor(panel)
        }
        chatLayout?.addView(item, LinearLayout.LayoutParams(-1, -2).apply {
            bottomMargin = 8
        })
    }
}
